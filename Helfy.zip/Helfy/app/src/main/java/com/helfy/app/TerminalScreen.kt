package com.helfy.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.min

@Composable
fun TerminalScreen(st: Settings, s: Session) {
    val c = st.theme()
    var input by remember { mutableStateOf(TextFieldValue("")) }
    val hist = remember { mutableStateListOf<String>() }
    var hi by remember { mutableIntStateOf(-1) }
    val listState = rememberLazyListState()
    val haptic = LocalHapticFeedback.current
    val fs = st.int("fontSize", 13).sp
    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = fs, lineHeight = fs * 1.3f)

    LaunchedEffect(s.lines.size) { if (s.lines.isNotEmpty()) listState.scrollToItem(s.lines.size - 1) }

    fun tap() { if (st.bool("vibrate", true)) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    fun setText(t: String) { input = TextFieldValue(t, TextRange(t.length)) }
    fun insert(x: String) {
        val a = min(input.selection.start, input.selection.end); val b = max(input.selection.start, input.selection.end)
        input = TextFieldValue(input.text.substring(0, a) + x + input.text.substring(b), TextRange(a + x.length))
    }
    fun send() {
        val t = input.text
        if (t.isNotBlank()) hist.add(t)
        hi = -1; input = TextFieldValue(""); s.submit(t)
    }

    Column(Modifier.fillMaxSize().background(c.bg).padding(st.int("margin", 6).dp)) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
            items(s.lines.size) { i ->
                val l = s.lines.getOrNull(i) ?: return@items
                Text(l.text, style = mono, color = when (l.kind) { 2 -> c.accent; 1 -> c.accent2; else -> c.fg })
            }
        }
        if (st.bool("extraKeys", true)) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                fun key(label: String, action: () -> Unit) = @Composable {
                    Text(label, color = c.accent, fontFamily = FontFamily.Monospace,
                        modifier = Modifier.background(c.surface, RoundedCornerShape(8.dp))
                            .clickable { tap(); action() }.padding(horizontal = 12.dp, vertical = 8.dp))
                }
                key("ESC") { setText("") }()
                key("TAB") { insert("\t") }()
                key("^C") { s.interrupt() }()
                key("^L") { s.lines.clear() }()
                key("↑") { if (hist.isNotEmpty()) { hi = if (hi < 0) hist.size - 1 else max(0, hi - 1); setText(hist[hi]) } }()
                key("↓") { if (hi >= 0) { hi++; if (hi >= hist.size) { hi = -1; setText("") } else setText(hist[hi]) } }()
                key("←") { val p = max(0, input.selection.start - 1); input = input.copy(selection = TextRange(p)) }()
                key("→") { val p = min(input.text.length, input.selection.end + 1); input = input.copy(selection = TextRange(p)) }()
                listOf("-", "/", "|", "~", "$", "\"", "'", "&", ">").forEach { ch -> key(ch) { insert(ch) }() }
            }
        }
        Row(Modifier.fillMaxWidth().background(c.surface, RoundedCornerShape(10.dp)).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(if (s.running) "▶" else s.prompt(), style = mono, color = c.accent2)
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                textStyle = mono.copy(color = c.fg), singleLine = true,
                cursorBrush = SolidColor(c.accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send, autoCorrect = false),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            Text("⏎", color = c.accent, modifier = Modifier.clickable { send() }.padding(start = 8.dp))
        }
    }
}
