package com.helfy.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

@Composable
fun EditorScreen(st: Settings, s: Session, goTerminal: () -> Unit) {
    val c = st.theme()
    val langs = allLangs(st)
    var lang by remember { mutableStateOf(langs[0]) }
    var name by remember { mutableStateOf("hello") }
    var code by remember { mutableStateOf(lang.sample) }
    var status by remember { mutableStateOf("") }
    var langMenu by remember { mutableStateOf(false) }
    var openMenu by remember { mutableStateOf(false) }
    val fs = st.int("fontSize", 13).sp

    fun file() = File(st.scripts(), "${name.trim().ifEmpty { "untitled" }}.${lang.ext}")
    fun save() { file().writeText(code); status = "Saved ${file().name}" }

    @Composable
    fun Btn(label: String, onClick: () -> Unit) = Text(label, color = c.accent,
        modifier = Modifier.background(c.surface, RoundedCornerShape(8.dp)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp))

    Column(Modifier.fillMaxSize().background(c.bg).padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BasicTextField(
                value = name, onValueChange = { name = it.filter { ch -> ch.isLetterOrDigit() || ch in "_-" } },
                modifier = Modifier.weight(1f).background(c.surface, RoundedCornerShape(8.dp)).padding(12.dp),
                textStyle = TextStyle(color = c.fg, fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                cursorBrush = SolidColor(c.accent), singleLine = true
            )
            Box {
                Btn(".${lang.ext}  ▾") { langMenu = true }
                DropdownMenu(langMenu, { langMenu = false }) {
                    langs.forEach { l -> DropdownMenuItem(text = { Text(l.name) }, onClick = {
                        lang = l; langMenu = false; if (code.isBlank()) code = l.sample }) }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box {
                Btn("Open") { openMenu = true }
                DropdownMenu(openMenu, { openMenu = false }) {
                    val files = st.scripts().listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()
                    if (files.isEmpty()) DropdownMenuItem(text = { Text("No scripts yet") }, onClick = { openMenu = false })
                    files.forEach { f -> DropdownMenuItem(text = { Text(f.name) }, onClick = {
                        name = f.nameWithoutExtension; code = f.readText()
                        lang = langs.firstOrNull { it.ext == f.extension } ?: lang
                        openMenu = false; status = "Opened ${f.name}" }) }
                }
            }
            Btn("New") { name = "untitled"; code = lang.sample; status = "" }
            Btn("Save") { save() }
            Btn("▶ Run") {
                save(); s.runScript(lang, file()); goTerminal()
            }
        }
        Text("${lang.name}${if (lang.builtin == null) " · needs ${lang.cmd.substringBefore(' ')} on PATH" else " · built-in"}   $status",
            color = c.accent2, fontSize = 12.sp)
        BasicTextField(
            value = code, onValueChange = { code = it },
            modifier = Modifier.weight(1f).fillMaxWidth().background(c.surface, RoundedCornerShape(10.dp))
                .padding(12.dp).verticalScroll(rememberScrollState()),
            textStyle = TextStyle(color = c.fg, fontFamily = FontFamily.Monospace, fontSize = fs, lineHeight = fs * 1.35f),
            cursorBrush = SolidColor(c.accent)
        )
    }
}
