package com.helfy.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(st: Settings) {
    val c = st.theme()

    @Composable fun Title(t: String) = Text(t.uppercase(), color = c.accent, fontSize = 12.sp,
        modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))

    @Composable fun Card(content: @Composable ColumnScope.() -> Unit) = Column(
        Modifier.fillMaxWidth().background(c.surface, RoundedCornerShape(12.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content)

    @Composable fun Switch(title: String, sub: String, key: String, def: Boolean) = Row(
        Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, color = c.fg); Text(sub, color = c.fg.copy(alpha = .6f), fontSize = 12.sp) }
        Switch(st.bool(key, def), { st.put(key, it) })
    }

    @Composable fun Slide(title: String, key: String, min: Int, max: Int, def: Int, unit: String = "") {
        Column {
            Text("$title: ${st.int(key, def)}$unit", color = c.fg)
            Slider(st.int(key, def).toFloat(), { st.put(key, it.roundToInt()) }, valueRange = min.toFloat()..max.toFloat())
        }
    }

    @Composable fun Field(title: String, key: String, def: String, multi: Boolean = false, hint: String = "") {
        OutlinedTextField(
            value = st.str(key, def), onValueChange = { st.put(key, it) },
            label = { Text(title) }, supportingText = if (hint.isNotEmpty()) ({ Text(hint) }) else null,
            singleLine = !multi, minLines = if (multi) 3 else 1,
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
            modifier = Modifier.fillMaxWidth())
    }

    Column(Modifier.fillMaxSize().background(c.bg).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Settings", color = c.fg, fontSize = 26.sp)

        Title("Appearance")
        Card {
            Text("Color theme", color = c.fg)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Themes.forEach { t ->
                    Box(Modifier.weight(1f).background(t.bg, RoundedCornerShape(8.dp))
                        .clickable { st.put("theme", t.name) }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                        Text(t.name, color = if (st.theme().name == t.name) t.accent else t.fg, fontSize = 11.sp)
                    }
                }
            }
            Slide("Font size", "fontSize", 8, 28, 13, "sp")
            Slide("Terminal margin", "margin", 0, 24, 6, "dp")
        }

        Title("Terminal")
        Card {
            Field("Shell path", "shell", "/system/bin/sh", hint = "e.g. /system/bin/sh or a bash you installed")
            Field("Home directory", "home", st.home())
            Field("Prompt symbol", "prompt", "❯")
            Field("Environment variables", "env", "", multi = true, hint = "One KEY=value per line")
            Slide("Scrollback lines", "scrollback", 200, 10000, 2000)
        }

        Title("Input")
        Card {
            Switch("Extra keys row", "ESC, TAB, arrows, ^C and symbols above the keyboard", "extraKeys", true)
            Switch("Vibrate on key press", "Haptic feedback on extra keys", "vibrate", true)
            Switch("Keep screen on", "Prevent the screen from sleeping", "keepOn", false)
        }

        Title("Languages")
        Card {
            Field("Custom interpreters", "custom", "", multi = true,
                hint = "One per line: name|ext|command   e.g.  Python 2|py|python2")
            Text("Built-in: JavaScript (Rhino) and Lua (LuaJ). Others need the interpreter on PATH (drop binaries in usr/bin).",
                color = c.fg.copy(alpha = .6f), fontSize = 12.sp)
        }

        Title("Data")
        Card {
            Text("Reset all settings", color = c.err,
                modifier = Modifier.clickable { st.reset() }.padding(vertical = 4.dp))
        }

        Title("About")
        Card { Text("Helfy 1.0 — scripting terminal.\nShell · JavaScript · Lua · Python · Node · Ruby · Perl · PHP · custom.", color = c.fg) }
        Spacer(Modifier.height(24.dp))
    }
}
