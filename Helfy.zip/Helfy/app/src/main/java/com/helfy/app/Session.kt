package com.helfy.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.luaj.vm2.lib.jse.JsePlatform
import org.mozilla.javascript.ScriptableObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.io.PrintStream
import kotlin.concurrent.thread

class Line(val text: String, val kind: Int) // 0 output, 1 system/error, 2 input

class Session(private val ctx: Context, private val st: Settings) {
    val lines = mutableStateListOf<Line>()
    var cwd by mutableStateOf(st.home())
    var running by mutableStateOf(false)
    private var proc: Process? = null
    private val main = Handler(Looper.getMainLooper())
    private val ansi = Regex("\u001B\\[[;?0-9]*[a-zA-Z]")

    init {
        print("Helfy 1.0  -  scripting terminal", 1)
        print("Type 'help' for commands. Home: ${st.home()}", 1)
    }

    fun print(t: String, kind: Int = 0) = main.post {
        lines.add(Line(ansi.replace(t, ""), kind))
        val max = st.int("scrollback", 2000)
        while (lines.size > max) lines.removeAt(0)
    }

    fun prompt() = "${File(cwd).name.ifEmpty { "/" }} ${st.str("prompt", "❯")}"

    fun submit(input: String) {
        if (running) {
            proc?.outputStream?.let { it.write((input + "\n").toByteArray()); it.flush() }
            print(input, 2); return
        }
        print("${prompt()} $input", 2)
        val t = input.trim()
        when {
            t.isEmpty() -> {}
            t == "clear" -> lines.clear()
            t == "help" -> HELP.lines().forEach { print(it, 1) }
            t == "cd" || t.startsWith("cd ") -> cd(t.removePrefix("cd").trim())
            else -> runProc(listOf(st.shell(), "-c", t))
        }
    }

    private fun cd(arg: String) {
        val target = when {
            arg.isEmpty() || arg == "~" -> File(st.home())
            arg.startsWith("~/") -> File(st.home(), arg.drop(2))
            arg.startsWith("/") -> File(arg)
            else -> File(cwd, arg)
        }.canonicalFile
        if (target.isDirectory) cwd = target.path else print("cd: no such directory: $arg", 1)
    }

    fun interrupt() { proc?.destroy(); print("^C", 1) }

    private fun runProc(cmd: List<String>) {
        running = true
        thread {
            try {
                val pb = ProcessBuilder(cmd).directory(File(cwd)).redirectErrorStream(true)
                val env = pb.environment()
                env["HOME"] = st.home(); env["HELFY_HOME"] = st.home(); env["TERM"] = "xterm-256color"
                env["PATH"] = st.bin() + ":" + (env["PATH"] ?: "/system/bin")
                env.putAll(st.env())
                val p = pb.start(); proc = p
                p.inputStream.bufferedReader().forEachLine { print(it) }
                val code = p.waitFor()
                if (code != 0) print("[exit $code]", 1)
            } catch (e: Exception) {
                print("helfy: ${e.message}", 1)
            } finally {
                proc = null; main.post { running = false }
            }
        }
    }

    fun runScript(lang: Lang, file: File) {
        print("▶ ${lang.name}: ${file.name}", 1)
        when (lang.builtin) {
            "js" -> builtin { out -> runJs(file, out) }
            "lua" -> builtin { out -> runLua(file, out) }
            else -> runProc(listOf(st.shell(), "-c", "${lang.cmd} '${file.absolutePath}'"))
        }
    }

    private inner class LineOut : OutputStream() {
        private val buf = ByteArrayOutputStream()
        override fun write(b: Int) {
            if (b == '\n'.code) flush() else buf.write(b)
        }
        override fun flush() { if (buf.size() > 0 || true) { print(buf.toString("UTF-8")); buf.reset() } }
    }

    private fun builtin(block: (PrintStream) -> Unit) {
        running = true
        thread {
            val out = PrintStream(LineOut(), false)
            try { block(out) } catch (e: Throwable) { print(e.message ?: e.toString(), 1) }
            finally { main.post { running = false } }
        }
    }

    private fun runJs(file: File, out: PrintStream) {
        val cx = org.mozilla.javascript.Context.enter()
        try {
            cx.optimizationLevel = -1 // required on Android
            val scope = cx.initStandardObjects()
            ScriptableObject.putProperty(scope, "__out", org.mozilla.javascript.Context.javaToJS(out, scope))
            cx.evaluateString(scope,
                "var console={log:function(){__out.println(Array.prototype.slice.call(arguments).join(' '));__out.flush();}};var print=console.log;",
                "prelude", 1, null)
            cx.evaluateString(scope, file.readText(), file.name, 1, null)
        } finally { org.mozilla.javascript.Context.exit() }
    }

    private fun runLua(file: File, out: PrintStream) {
        val g = JsePlatform.standardGlobals()
        g.STDOUT = out
        g.load(file.readText(), file.name).call()
        out.flush()
    }

    companion object {
        const val HELP = """Commands:
  help            show this help
  clear           clear the screen
  cd <dir>        change directory (~ = home)
  <anything>      runs in your shell (sh by default)
Scripts live in ~/scripts. Use the Editor tab to write and run them.
Put extra interpreters/binaries in usr/bin (added to PATH).
Add custom languages in Settings > Languages."""
    }
}
