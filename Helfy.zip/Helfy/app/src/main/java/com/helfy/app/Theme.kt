package com.helfy.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

data class HColors(
    val name: String, val bg: Color, val surface: Color, val fg: Color,
    val accent: Color, val accent2: Color, val err: Color, val dark: Boolean = true
)

val Themes = listOf(
    HColors("Neon", Color(0xFF0B0F1A), Color(0xFF131A2B), Color(0xFFE6F1FF), Color(0xFF00E5FF), Color(0xFFB388FF), Color(0xFFFF5370)),
    HColors("Matrix", Color(0xFF000000), Color(0xFF07120A), Color(0xFF9DFFB0), Color(0xFF00FF66), Color(0xFF39FF14), Color(0xFFFF5555)),
    HColors("Amber", Color(0xFF14100A), Color(0xFF211A10), Color(0xFFFFE0B2), Color(0xFFFFB300), Color(0xFFFF7043), Color(0xFFFF5252)),
    HColors("Dracula", Color(0xFF282A36), Color(0xFF343746), Color(0xFFF8F8F2), Color(0xFFBD93F9), Color(0xFFFF79C6), Color(0xFFFF5555)),
    HColors("Light", Color(0xFFF7F9FC), Color(0xFFE8EDF5), Color(0xFF1B2330), Color(0xFF0066FF), Color(0xFF7C4DFF), Color(0xFFD32F2F), dark = false)
)

@Composable
fun HelfyTheme(c: HColors, content: @Composable () -> Unit) {
    val scheme = if (c.dark) darkColorScheme(
        primary = c.accent, secondary = c.accent2, background = c.bg, surface = c.surface,
        onSurface = c.fg, onBackground = c.fg, onPrimary = c.bg
    ) else lightColorScheme(
        primary = c.accent, secondary = c.accent2, background = c.bg, surface = c.surface,
        onSurface = c.fg, onBackground = c.fg, onPrimary = Color.White
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
