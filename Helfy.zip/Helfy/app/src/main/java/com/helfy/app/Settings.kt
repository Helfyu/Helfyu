package com.helfy.app

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import java.io.File

/** Persistent, Compose-observable settings (Termux-style). */
class Settings(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("helfy", Context.MODE_PRIVATE)
    private val map = mutableStateMapOf<String, String>().apply {
        sp.all.forEach { (k, v) -> put(k, v.toString()) }
    }

    fun str(k: String, d: String) = map[k] ?: d
    fun int(k: String, d: Int) = map[k]?.toIntOrNull() ?: d
    fun bool(k: String, d: Boolean) = map[k]?.toBooleanStrictOrNull() ?: d
    fun put(k: String, v: Any) { map[k] = v.toString(); sp.edit().putString(k, v.toString()).apply() }
    fun reset() { map.clear(); sp.edit().clear().apply() }

    fun home(): String = str("home", File(ctx.filesDir, "home").absolutePath).also { File(it).mkdirs() }
    fun bin(): String = File(ctx.filesDir, "usr/bin").apply { mkdirs() }.absolutePath
    fun scripts(): File = File(home(), "scripts").apply { mkdirs() }
    fun shell() = str("shell", "/system/bin/sh")
    fun theme() = Themes.firstOrNull { it.name == str("theme", "Neon") } ?: Themes[0]
    fun env(): Map<String, String> = str("env", "").lines().mapNotNull {
        val i = it.indexOf('=')
        if (i > 0) it.substring(0, i).trim() to it.substring(i + 1).trim() else null
    }.toMap()
}
