package com.helfy.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val st = Settings(this)
        val session = Session(this, st)
        setContent {
            val c = st.theme()
            var tab by remember { mutableIntStateOf(0) }
            val keepOn = st.bool("keepOn", false)
            LaunchedEffect(keepOn) {
                if (keepOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
            HelfyTheme(c) {
                Scaffold(
                    containerColor = c.bg,
                    bottomBar = {
                        NavigationBar(containerColor = c.surface) {
                            listOf("❯_" to "Terminal", "✎" to "Editor", "⚙" to "Settings").forEachIndexed { i, (ic, label) ->
                                NavigationBarItem(
                                    selected = tab == i, onClick = { tab = i },
                                    icon = { Text(ic, color = if (tab == i) c.accent else c.fg) },
                                    label = { Text(label) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedTextColor = c.accent, unselectedTextColor = c.fg,
                                        indicatorColor = c.bg)
                                )
                            }
                        }
                    }
                ) { pad ->
                    Box(Modifier.padding(pad)) {
                        when (tab) {
                            0 -> TerminalScreen(st, session)
                            1 -> EditorScreen(st, session) { tab = 0 }
                            else -> SettingsScreen(st)
                        }
                    }
                }
            }
        }
    }
}
