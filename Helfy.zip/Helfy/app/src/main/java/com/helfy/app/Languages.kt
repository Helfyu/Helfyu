package com.helfy.app

/** A scripting language. builtin = runs inside Helfy with no install; otherwise needs an interpreter on PATH. */
data class Lang(val name: String, val ext: String, val cmd: String, val builtin: String? = null, val sample: String)

val BuiltinLangs = listOf(
    Lang("Shell", "sh", "sh", null, "echo \"Hello from Helfy\"\nuname -a\nls -la\n"),
    Lang("JavaScript (built-in)", "js", "", "js", "console.log('Hello from Helfy');\nfor (var i = 1; i <= 3; i++) console.log('count', i);\n"),
    Lang("Lua (built-in)", "lua", "", "lua", "print('Hello from Helfy')\nfor i = 1, 3 do print('count', i) end\n"),
    Lang("Bash", "bash", "bash", null, "#!/usr/bin/env bash\necho \"Hello from Helfy\"\n"),
    Lang("Python", "py", "python3", null, "print('Hello from Helfy')\n"),
    Lang("Node.js", "mjs", "node", null, "console.log('Hello from Helfy')\n"),
    Lang("Ruby", "rb", "ruby", null, "puts 'Hello from Helfy'\n"),
    Lang("Perl", "pl", "perl", null, "print \"Hello from Helfy\\n\";\n"),
    Lang("PHP", "php", "php", null, "<?php\necho \"Hello from Helfy\\n\";\n"),
    Lang("Awk", "awk", "awk -f", null, "BEGIN { print \"Hello from Helfy\" }\n"),
    Lang("Go (go run)", "go", "go run", null, "package main\nimport \"fmt\"\nfunc main() { fmt.Println(\"Hello from Helfy\") }\n"),
    Lang("R", "r", "Rscript", null, "cat('Hello from Helfy\\n')\n")
)

/** Built-ins + custom interpreters from Settings (one per line: name|ext|command). */
fun allLangs(st: Settings): List<Lang> {
    val custom = st.str("custom", "").lines().mapNotNull {
        val p = it.split("|").map { s -> s.trim() }
        if (p.size >= 3 && p[0].isNotEmpty()) Lang(p[0], p[1], p[2], null, "") else null
    }
    return BuiltinLangs + custom
}
