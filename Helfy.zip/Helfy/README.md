# Helfy — scripting terminal for Android

Terminal + script editor + Termux-style settings, Jetpack Compose, 5 themes.

## Build the APK
1. Install Android Studio (Koala or newer) and open this folder.
2. Let Gradle sync (it downloads dependencies; it will offer to create the Gradle wrapper).
3. Build > Build Bundle(s) / APK(s) > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
   (or press Run with a phone attached).
CLI: `gradle wrapper && ./gradlew assembleDebug`

## Languages
- Built-in, no install: JavaScript (Rhino), Lua (LuaJ), Shell (/system/bin/sh)
- External (Python, Node, Ruby, Perl, PHP, Awk, Go, R, Bash): put the binary in
  <app files>/usr/bin (already on PATH) or set a path. Add more in Settings > Languages.

## Layout
- Session.kt  process + built-in runtimes   - Languages.kt  language registry
- TerminalScreen / EditorScreen / SettingsScreen / Theme / Settings
Scripts are stored in ~/scripts.

## Build without a PC (GitHub)
1. Create a free GitHub account and a new repository.
2. Upload all files from this folder (keep the .github folder).
3. Open the Actions tab > "Build APK" > wait ~5 min.
4. Open the finished run, download the "Helfy-apk" artifact, unzip, install app-debug.apk.
   (Allow "install unknown apps" for your browser/files app when asked.)
